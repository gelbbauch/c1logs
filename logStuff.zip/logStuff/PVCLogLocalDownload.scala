// Databricks notebook source
// MAGIC %md # Private Cloud Log Local Download Notebook
// MAGIC 
// MAGIC This notebook downloads logs collected through Databricks services from your root S3 bucket to your local. To use:
// MAGIC 1. Launch a cluster with the LogUtil jar provided by Databricks Support.
// MAGIC 2. Fill in the information regarding your deployment below.
// MAGIC 3. Fill in the widgets above. If the widgets don't show up, you may need to do a Run All first. You can use Support ticket numbers for the incident field.
// MAGIC 4. Click Run All once everything is filled in
// MAGIC 
// MAGIC Service Definitions (You will be directed by Databricks support on which service to choose):
// MAGIC  - For errors regarding **Spark Clusters**, please use Spark.
// MAGIC    - `Cluster Id` widget is required
// MAGIC    - `Instance Ids` widget is required. Put `all` if selecting logs for all instances within the cluster. You can choose multiple instances and use commas to separate (ex: id1, id2, .. ).
// MAGIC    - Please check `DatabricksSupportSparkClusterInfos` Notebook to identify which cluster/instances to choose.

// COMMAND ----------

val sourceBucket = "deepaktests3/" // FILL THIS IN. This is your deployment's root S3 bucket
val sourceRegion = "us-west-2" // FILL THIS IN. This is the region of your deployment's root S3 bucket
val deploymentName = "dbcustsuccess" // FILL THIS IN. This is your deployment "Shard Name". This can be provided to you by Databricks support

// COMMAND ----------

implicit class EZRow(row: Row) {
  def getStr(colName: String): String = row.getAs[String](colName)
}

// COMMAND ----------

//Create Util Functions

import org.joda.time.{DateTime, DateTimeZone}
import org.joda.time.format.{DateTimeFormat, DateTimeFormatter, ISODateTimeFormat}
import org.apache.commons.lang.StringUtils
import org.apache.hadoop.fs._
import scala.sys.process._
import java.util.UUID
import scala.collection.JavaConversions._
import org.apache.spark.sql.{Column, DataFrame, Row}
import org.apache.spark.sql.functions._
import org.apache.commons.io.{IOUtils, FileUtils}
import org.apache.commons.lang.StringUtils
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.conf.Configuration
import java.util.UUID
import java.io.{OutputStream, FileOutputStream, BufferedOutputStream, File}
import java.nio.charset.StandardCharsets

import scala.sys.process._
import scala.collection.JavaConversions._
import scala.collection.mutable

import org.apache.commons.io.{IOUtils, FileUtils}
import org.apache.commons.lang.StringUtils
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.conf.Configuration
import org.joda.time.{DateTime, DateTimeZone}
import org.joda.time.format.{DateTimeFormat, DateTimeFormatter, ISODateTimeFormat}

import org.apache.spark.sql.{Column, DataFrame, Row}
import org.apache.spark.sql.functions._



/**
 * Writes messages to local files under the output directory over an iterator of rows. 
 * The function argument `getMessage` will be applied on each row to extract (path, message) pairs.
 * TODO: Merge this method with the code from LogDump.
 */
def writeMessagesToLocalFiles(
    rows: Iterator[Row],
    getMessage: Row => (String, String),
    outputDir: String): Unit = {
  var outputStream: OutputStream = null
  var outputPath: String = null
  rows.foreach { row =>
    val (path, message) = getMessage(row)
    if (message == null) {
      println("Test - " + message)
    } else {
      val newOutputPath = s"$outputDir/$path"
      if (newOutputPath != outputPath) {
        IOUtils.closeQuietly(outputStream)
        outputPath = newOutputPath
        val outputFile = new File(outputPath)
        outputFile.getParentFile().mkdirs()
        outputStream = new BufferedOutputStream(new FileOutputStream(outputFile))
      }
      outputStream.write(message.getBytes(StandardCharsets.UTF_8))
    }
  }
  IOUtils.closeQuietly(outputStream)
}


def getTimeZone(timezone: String): DateTimeZone = timezone.toLowerCase match {
  case "utc" => DateTimeZone.UTC
  case "pacific" => DateTimeZone.forID("America/Los_Angeles")
  case _ => throw new IllegalArgumentException(s"Expected 'Pacific' or 'UTC' for timezone. Instead got: $timezone.")
}

// Convert the start and end time from string to UTC DateTime.
def getDateTimePair(start: String, end: String, tz: String): (DateTime, DateTime) = {
  require(!StringUtils.isBlank(start), "start time must be specified")
  require(!StringUtils.isBlank(end), "end time must be specified")

  val fmt = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss").withZone(getTimeZone(tz))
  val dateTimeStart = fmt.parseDateTime(start).toDateTime(DateTimeZone.UTC)
  val dateTimeEnd = fmt.parseDateTime(end).toDateTime(DateTimeZone.UTC)
  (dateTimeStart, dateTimeEnd)
}

/** Generates a glob string of `yyyy-MM-dd` date strings for the given time range. */
def getDateGlob(start: DateTime, end: DateTime): String = {
  val dateFmt = DateTimeFormat.forPattern("yyyy-MM-dd")
  var t = start.withTimeAtStartOfDay
  val dates = new scala.collection.mutable.ArrayBuffer[String]()
  while (t.isBefore(end)) {
    dates += dateFmt.print(t)
    t = t.plusDays(1)
  }
  require(dates.nonEmpty, s"$start and $end don't give a valid date range.")
  dates.mkString("{", ",", "}")
}

def dumpSparkLogs(df: DataFrame, outputName: String): Unit = {
  // instance ID has 1-1 mapping with container IP
  def getFileName(row: Row): String = {
    val service = row.getStr("service")
    val ip: String = row.getStr("ip")
    val appId: String = row.getStr("appId") 
    val workerId: String = row.getStr("workerId")
    val logType: String = row.getStr("logType")
    if (Seq("driver", "spark-master", "spark-worker", "databricks-driver", "databricks-chauffeur", "eventlog").contains(service)) {
      Seq(service, ip, logType).mkString("/") + ".txt"
    } else if (service == "executor") {
      Seq(service, ip, appId, workerId, logType).mkString("/") + ".txt"
    } else {
      println(s"Unknown service: $service")
       Seq("unknown", ip, logType).mkString("/") + ".txt"
    }
  }
  val fileNameCols = Seq[Column]('service, 'ip, 'appId, 'workerId, 'logType)
  val sorted = df.select(
    fileNameCols ++ Seq[Column](
      'instanceId,
      'time,
      'streamOffset.as('offset),
      'logMessage.as('message)): _*)
   .repartition(1)
   .sortWithinPartitions(fileNameCols ++ Seq[Column]('offset): _*)
   .rdd
  assert(sorted.partitions.length == 1)
  val outputFile = s"$outputName.tar.gz"
  val dbfsPath = s"logDump/spark-logs/$outputFile"
  sorted.foreachPartition { rows =>
    assert(rows.nonEmpty,
      "No logs found. Spark logs are available since 2.15. Please also check whether the cluster was active during the specified period.")
    val baseDir = "/local_disk0/tmp" + UUID.randomUUID
    val localOutputDir = s"$baseDir/$outputName"
    val localZipFilePath = s"$baseDir/$outputFile"
    val fs = FileSystem.get(new Configuration)
    writeMessagesToLocalFiles(rows, row => (getFileName(row), row.getStr("message")), localOutputDir)
    assert(s"tar zcf $localZipFilePath -C $baseDir $outputName/".! == 0, "Failed to zip files.")
    fs.copyFromLocalFile(new Path(localZipFilePath), new Path(s"dbfs:/FileStore/$dbfsPath"))
    FileUtils.deleteQuietly(new File(localOutputDir))
    FileUtils.deleteQuietly(new File(localZipFilePath))
  }
  val link = s"/files/$dbfsPath"
  displayHTML(s"""
  <a href=$link download>Download Spark logs: $outputFile</a>
  """)
}

// COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("incident", "", "1. Incident Id")
val serviceMap = scala.collection.immutable.ListMap(
  "Spark" -> "spark-log"
  //"Webapp" -> "webapp",
  //"Cluster Manager" -> "manager",
  //"Jobs" -> "elastic-spark",
  //"S3 Commit Service" -> "sisyphus",
  //"Data" -> "data",
  //"Node" -> "node",
  //"Log Uploading" -> "log-daemon",
  //"Secret Management" -> "secret-manager",
  //"Debug Snapshots" -> "debug-snapshots"
)
dbutils.widgets.dropdown("service", "Spark", serviceMap.keys.toSeq, "2. Service")
dbutils.widgets.text("startTime", "", "3. Start Time (yyyy-MM-dd-HH)")
dbutils.widgets.text("endTime", "", "4. End Time (yyyy-MM-dd-HH)")
dbutils.widgets.dropdown("tz", "Pacific", Seq("UTC", "Pacific"), "5. Time Zone")

val service = dbutils.widgets.get("service")
val internalService = serviceMap(service)
if (internalService == "spark-log") {
  dbutils.widgets.text("clusterId", "", "6. Cluster Id")
  dbutils.widgets.text("instanceIds", "all", "7. Instance Ids (all/id1, id2..)")
} else {
  try {
    dbutils.widgets.remove("clusterId")
    dbutils.widgets.remove("instanceIds")
  } catch {
    case _: com.databricks.dbutils_v1.InputWidgetNotDefined => // fine
  }
}

// COMMAND ----------

import org.apache.spark.util.SerializableConfiguration
import org.apache.hadoop.fs._
import org.apache.spark.sql.Encoders
import com.databricks.log.process.SparkLogETL
import com.databricks.log.process.util.MessageWrapper

val incident = dbutils.widgets.get("incident")
val startTime = dbutils.widgets.get("startTime")
val endTime = dbutils.widgets.get("endTime")
val tz = dbutils.widgets.get("tz")
val clusterId = try Option(dbutils.widgets.get("clusterId")) catch {
  case _: com.databricks.dbutils_v1.InputWidgetNotDefined => None
}
val instanceIds = try Option(dbutils.widgets.get("instanceIds")) catch {
  case _: com.databricks.dbutils_v1.InputWidgetNotDefined => None
}

val cluster=clusterId.getOrElse("")
val instanceIdList = instanceIds.getOrElse("").split(", ")
val useSelectedInstanceIds = if (instanceIdList.length == 1 && instanceIdList(0).toLowerCase == "all") false else true
val (start, end) = getDateTimePair(startTime, endTime, tz)
val dateGlob = getDateGlob(start, end)  
val basePath = s"s3a://$sourceBucket/databricks-logs/$deploymentName/log-sync-internal/system-log-v2"
val hadoopConf = spark.sessionState.newHadoopConf()
val serHdpConf = new SerializableConfiguration(hadoopConf)
val driverFs = new Path(basePath).getFileSystem(hadoopConf)
val logInstanceIds = if (useSelectedInstanceIds) {
    instanceIdList.toSeq
  } else {
    driverFs.globStatus(new Path(basePath, s"$dateGlob/${cluster}_*/*")).map(_.getPath.getName).toSeq
  }

val outputName = s"${deploymentName}_${incident}_${service}"

val instanceGlob = logInstanceIds.mkString("{", ",", "}")
val df = spark.read.schema(Encoders.product[MessageWrapper].schema).json(s"s3a://$sourceBucket/databricks-logs/$deploymentName/log-sync-internal/archived-log/spark-log/$dateGlob/$instanceGlob")
    // We don't deduplicate, because it is very low probability to have duplicates in PVC since we don't use Kinesis
val readableLogs = SparkLogETL.transform(df, false).where("clusterId=+"clusterId)

// COMMAND ----------

println(s"""
Running with parameters:

incident: $incident
service: $service
startTime: $startTime
endTime: $endTime
tz: $tz
""")
dumpSparkLogs(readableLogs, outputName)
